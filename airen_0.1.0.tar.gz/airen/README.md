# airen_r
airen: A R package to optimize the performance of Restriction digestion to improve the resolution of WGS
